# The Battleship game for console
___
## instalation:
For instalation just clone the repository:
```
git clone https://github.com/Myralllka/battleship
```
Then move to the __battleship__ directory:
```
cd battleship
```
make main script executable:
```
chmod +x main.py
```
and than you can start the game using the command:
```
./main.py
```
## Remarks:
You need to have already installed python3.7 interpreter to start this game.
