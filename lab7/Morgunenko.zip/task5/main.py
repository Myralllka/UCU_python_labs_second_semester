#!/bin/env ipython

from bird_test import *
from book_test import *
from eq_test import *

if __name__ == '__main__':
    testBirdClasses()
    testBookClass()
    testEquationClasses()
